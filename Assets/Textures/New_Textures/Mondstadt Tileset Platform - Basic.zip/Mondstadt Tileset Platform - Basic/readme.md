# Mondstadt Theme - Genshin Inspired - Parallax Background Pixel Art (Free Platformer Tileset)

## Thank you for downloading the assets!

If you have any question please discuss on itch io page discussion or directly email to hello@theflavare.com . Any question and suggest are welcome.

Unity Demo project purpose to give example and demo from our assets. Please do not use this for your production.

## Heads Up!

- Tileset at 32x32
- All Unity Demo are using 2021.3.11f1

## Important!

1. You CAN use in your project in any commercial or non-commercial projects;
2. You CAN'T resold or redistributed this assets;
3. Credit appreciated;

## Finally

Follow us more on Twitter [@theflavare](https://twitter.com/@theflavare)

---

\*Last Update 2024-03-25
