<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="basic" tilewidth="32" tileheight="32" tilecount="1089" columns="33">
 <image source="Free.png" width="1056" height="1056"/>
</tileset>
